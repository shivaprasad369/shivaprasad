(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [590],
  {
    281: function (e, s, i) {
      Promise.resolve().then(i.bind(i, 1723)),
        Promise.resolve().then(i.bind(i, 1183)),
        Promise.resolve().then(i.bind(i, 5719)),
        Promise.resolve().then(i.bind(i, 2817)),
        Promise.resolve().then(i.t.bind(i, 8173, 23)),
        Promise.resolve().then(i.t.bind(i, 231, 23));
    },
    1723: function (e, s, i) {
      "use strict";
      i.d(s, {
        default: function () {
          return c;
        },
      });
      var a = i(7437),
        l = i(6648);
      function t() {
        return (0, a.jsxs)(a.Fragment, {
          children: [
            (0, a.jsxs)("div", {
              className: "blog-single-comment d-flex gap-4 pt-4 pb-5",
              children: [
                (0, a.jsx)("div", {
                  className: "image",
                  children: (0, a.jsx)(l.default, {
                    src: "/assets/img/news/comment-1.png",
                    width: 96,
                    height: 96,
                    alt: "image",
                  }),
                }),
                (0, a.jsxs)("div", {
                  className: "content",
                  children: [
                    (0, a.jsxs)("div", {
                      className:
                        "head d-flex flex-wrap gap-2 align-items-center justify-content-between",
                      children: [
                        (0, a.jsxs)("div", {
                          className: "con",
                          children: [
                            (0, a.jsx)("h5", {
                              children: (0, a.jsx)("a", {
                                href: "news-details.html",
                                children: "Albert Flores",
                              }),
                            }),
                            (0, a.jsx)("span", {
                              children: "February 10, 2024 at 2:37 pm",
                            }),
                          ],
                        }),
                        (0, a.jsxs)("div", {
                          className: "star",
                          children: [
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                          ],
                        }),
                      ],
                    }),
                    (0, a.jsx)("p", {
                      className: "mt-30 mb-4",
                      children:
                        "Neque porro est qui dolorem ipsum quia quaed inventor veritatis et quasi architecto var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy",
                    }),
                    (0, a.jsx)("a", {
                      href: "news-details.html",
                      className: "reply",
                      children: "Reply",
                    }),
                  ],
                }),
              ],
            }),
            (0, a.jsxs)("div", {
              className: "blog-single-comment d-flex gap-4 pt-5 pb-5",
              children: [
                (0, a.jsx)("div", {
                  className: "image",
                  children: (0, a.jsx)(l.default, {
                    src: "/assets/img/news/comment-2.png",
                    width: 96,
                    height: 96,
                    alt: "image",
                  }),
                }),
                (0, a.jsxs)("div", {
                  className: "content",
                  children: [
                    (0, a.jsxs)("div", {
                      className:
                        "head d-flex flex-wrap gap-2 align-items-center justify-content-between",
                      children: [
                        (0, a.jsxs)("div", {
                          className: "con",
                          children: [
                            (0, a.jsx)("h5", {
                              children: (0, a.jsx)("a", {
                                href: "news-details.html",
                                children: "Alex Flores",
                              }),
                            }),
                            (0, a.jsx)("span", {
                              children: "February 10, 2024 at 2:37 pm",
                            }),
                          ],
                        }),
                        (0, a.jsxs)("div", {
                          className: "star",
                          children: [
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                            (0, a.jsx)("i", { className: "fa-solid fa-star" }),
                          ],
                        }),
                      ],
                    }),
                    (0, a.jsx)("p", {
                      className: "mt-30 mb-4",
                      children:
                        "Neque porro est qui dolorem ipsum quia quaed inventor veritatis et quasi architecto var sed efficitur turpis gilla sed sit amet finibus eros. Lorem Ipsum is simply dummy",
                    }),
                    (0, a.jsx)("a", {
                      href: "news-details.html",
                      className: "reply color-2",
                      children: "Reply",
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      }
      function n() {
        return (0, a.jsx)("form", {
          onSubmit: (e) => e.preventDefault(),
          children: (0, a.jsxs)("div", {
            className: "row g-4",
            children: [
              (0, a.jsx)("div", {
                className: "col-lg-6",
                children: (0, a.jsxs)("div", {
                  className: "form-clt",
                  children: [
                    (0, a.jsx)("span", { children: "Your Name*" }),
                    (0, a.jsx)("input", {
                      type: "text",
                      name: "name",
                      id: "name",
                      placeholder: "Your Name",
                    }),
                  ],
                }),
              }),
              (0, a.jsx)("div", {
                className: "col-lg-6",
                children: (0, a.jsxs)("div", {
                  className: "form-clt",
                  children: [
                    (0, a.jsx)("span", { children: "Your Email*" }),
                    (0, a.jsx)("input", {
                      type: "text",
                      name: "email",
                      id: "email2",
                      placeholder: "Your Email",
                    }),
                  ],
                }),
              }),
              (0, a.jsx)("div", {
                className: "col-lg-12",
                children: (0, a.jsxs)("div", {
                  className: "form-clt",
                  children: [
                    (0, a.jsx)("span", { children: "Message*" }),
                    (0, a.jsx)("textarea", {
                      name: "message",
                      id: "message",
                      placeholder: "Write Message",
                      defaultValue: "",
                    }),
                  ],
                }),
              }),
              (0, a.jsx)("div", {
                className: "col-lg-6",
                children: (0, a.jsxs)("button", {
                  type: "submit",
                  className: "theme-btn",
                  children: [
                    "post comment",
                    (0, a.jsx)("i", {
                      className: "fa-solid fa-arrow-right-long",
                    }),
                  ],
                }),
              }),
            ],
          }),
        });
      }
      i(2265);
      var r = i(8757),
        d = i(7138);
      function c(e) {
        let { newsItem: s } = e;
        return (0, a.jsx)("section", {
          className: "news-standard fix section-padding",
          children: (0, a.jsx)("div", {
            className: "container",
            children: (0, a.jsxs)("div", {
              className: "row g-4",
              children: [
                (0, a.jsx)("div", {
                  className: "col-12 col-lg-8",
                  children: (0, a.jsxs)("div", {
                    className: "blog-post-details",
                    children: [
                      (0, a.jsxs)("div", {
                        className: "single-blog-post",
                        children: [
                          (0, a.jsx)("div", {
                            className: "post-featured-thumb bg-cover",
                            style: {
                              backgroundImage:
                                'url("/assets/img/news/post-4.jpg")',
                            },
                          }),
                          (0, a.jsxs)("div", {
                            className: "post-content",
                            children: [
                              (0, a.jsxs)("ul", {
                                className:
                                  "post-list d-flex align-items-center",
                                children: [
                                  (0, a.jsxs)("li", {
                                    children: [
                                      (0, a.jsx)("i", {
                                        className: "fa-regular fa-user",
                                      }),
                                      "By Admin",
                                    ],
                                  }),
                                  (0, a.jsxs)("li", {
                                    children: [
                                      (0, a.jsx)("i", {
                                        className: "fa-solid fa-calendar-days",
                                      }),
                                      "18 Dec, 2024",
                                    ],
                                  }),
                                  (0, a.jsxs)("li", {
                                    children: [
                                      (0, a.jsx)("i", {
                                        className: "fa-solid fa-tag",
                                      }),
                                      "Technology",
                                    ],
                                  }),
                                ],
                              }),
                              (0, a.jsx)("h3", { children: s.title }),
                              (0, a.jsx)("p", {
                                className: "mb-3",
                                children:
                                  "Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore of magna aliqua. Ut enim ad minim veniam, made of owl the quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea dolor commodo consequat. Duis aute irure and dolor in reprehenderit.",
                              }),
                              (0, a.jsx)("p", {
                                className: "mb-3",
                                children:
                                  "The is ipsum dolor sit amet consectetur adipiscing elit. Fusce eleifend porta arcu In hac habitasse the is platea augue thelorem turpoi dictumst. In lacus libero faucibus at malesuada sagittis placerat eros sed istincidunt augue ac ante rutrum sed the is sodales augue consequat.",
                              }),
                              (0, a.jsx)("p", {
                                children:
                                  "Nulla facilisi. Vestibulum tristique sem in eros eleifend imperdiet. Donec quis convallis neque. In id lacus pulvinar lacus, eget vulputate lectus. Ut viverra bibendum lorem, at tempus nibh mattis in. Sed a massa eget lacus consequat auctor.",
                              }),
                              (0, a.jsxs)("div", {
                                className: "hilight-text mt-4 mb-4",
                                children: [
                                  (0, a.jsx)("p", {
                                    children:
                                      "Pellentesque sollicitudin congue dolor non aliquam. Morbi volutpat, nisi vel ultricies urnacondimentum, sapien neque lobortis tortor, quis efficitur mi ipsum eu metus. Praesent eleifend orci sit amet est vehicula.",
                                  }),
                                  (0, a.jsxs)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: 36,
                                    height: 36,
                                    viewBox: "0 0 36 36",
                                    fill: "none",
                                    children: [
                                      (0, a.jsx)("path", {
                                        d: "M7.71428 20.0711H0.5V5.64258H14.9286V20.4531L9.97665 30.3568H3.38041L8.16149 20.7947L8.5233 20.0711H7.71428Z",
                                        stroke: "#F55B1F",
                                      }),
                                      (0, a.jsx)("path", {
                                        d: "M28.2846 20.0711H21.0703V5.64258H35.4989V20.4531L30.547 30.3568H23.9507L28.7318 20.7947L29.0936 20.0711H28.2846Z",
                                        stroke: "#F55B1F",
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              (0, a.jsx)("p", {
                                className: "mt-4 mb-5",
                                children:
                                  "Lorem ipsum dolor sit amet consectetur adipiscing elit Ut et massa mi. Aliquam in hendrerit urna. Pellentesque sit amet sapien fringilla, mattis ligula consectetur, ultrices mauris. Maecenas vitae mattis tellus. Nullam quis imperdiet augue. Vestibulum auctor ornare leo, non suscipit magna interdum eu. Curabitur pellentesque nibh nibh, at maximus ante fermentum sit amet. Pellentesque commodo lacus at sodales sodales. Quisque sagittis orci ut diam condimentum, vel euismod erat placerat. In iaculis arcu eros.",
                              }),
                              (0, a.jsxs)("div", {
                                className: "row g-4",
                                children: [
                                  (0, a.jsx)("div", {
                                    className: "col-lg-6",
                                    children: (0, a.jsx)("div", {
                                      className: "details-image",
                                      children: (0, a.jsx)(l.default, {
                                        src: "/assets/img/news/post-5.jpg",
                                        width: 370,
                                        height: 269,
                                        alt: "img",
                                      }),
                                    }),
                                  }),
                                  (0, a.jsx)("div", {
                                    className: "col-lg-6",
                                    children: (0, a.jsx)("div", {
                                      className: "details-image",
                                      children: (0, a.jsx)(l.default, {
                                        src: "/assets/img/news/post-6.jpg",
                                        width: 370,
                                        height: 269,
                                        alt: "img",
                                      }),
                                    }),
                                  }),
                                ],
                              }),
                              (0, a.jsx)("p", {
                                className: "pt-5",
                                children:
                                  "Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore of magna aliqua. Ut enim ad minim veniam, made of owl the quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea dolor commodo consequat. Duis aute irure and dolor in reprehenderit.Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore of magna aliqua. Ut enim ad minim veniam, made of owl the quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea dolor commodo consequat. Duis aute irure and dolor in reprehenderit.",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "row tag-share-wrap mt-4 mb-5",
                        children: [
                          (0, a.jsx)("div", {
                            className: "col-lg-8 col-12",
                            children: (0, a.jsxs)("div", {
                              className: "tagcloud",
                              children: [
                                (0, a.jsx)("span", { children: "Tags:" }),
                                (0, a.jsx)("a", {
                                  href: "#",
                                  children: "Travel",
                                }),
                                (0, a.jsx)("a", {
                                  href: "#",
                                  children: "Services",
                                }),
                                (0, a.jsx)("a", {
                                  href: "#",
                                  children: "Agency",
                                }),
                              ],
                            }),
                          }),
                          (0, a.jsx)("div", {
                            className:
                              "col-lg-4 col-12 mt-3 mt-lg-0 text-lg-end",
                            children: (0, a.jsxs)("div", {
                              className: "social-share",
                              children: [
                                (0, a.jsx)("span", {
                                  className: "me-3",
                                  children: "Share:",
                                }),
                                r.KT.map((e, s) =>
                                  (0, a.jsx)(
                                    "a",
                                    {
                                      href: e.href,
                                      children: (0, a.jsx)("i", {
                                        className: e.iconClass,
                                      }),
                                    },
                                    s
                                  )
                                ),
                              ],
                            }),
                          }),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "comments-area",
                        children: [
                          (0, a.jsx)("div", {
                            className: "comments-heading",
                            children: (0, a.jsx)("h3", {
                              children: "02 Comments",
                            }),
                          }),
                          (0, a.jsx)(t, {}),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "comment-form-wrap pt-5",
                        children: [
                          (0, a.jsx)("h3", { children: "Leave a comments" }),
                          (0, a.jsx)(n, {}),
                        ],
                      }),
                    ],
                  }),
                }),
                (0, a.jsx)("div", {
                  className: "col-12 col-lg-4",
                  children: (0, a.jsxs)("div", {
                    className: "main-sidebar",
                    children: [
                      (0, a.jsxs)("div", {
                        className: "single-sidebar-widget",
                        children: [
                          (0, a.jsx)("div", {
                            className: "wid-title",
                            children: (0, a.jsx)("h3", { children: "Search" }),
                          }),
                          (0, a.jsx)("div", {
                            className: "search-widget",
                            children: (0, a.jsxs)("form", {
                              onSubmit: (e) => e.preventDefault(),
                              children: [
                                (0, a.jsx)("input", {
                                  type: "text",
                                  placeholder: "Search here",
                                }),
                                (0, a.jsx)("button", {
                                  type: "submit",
                                  children: (0, a.jsx)("i", {
                                    className: "fa-solid fa-magnifying-glass",
                                  }),
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "single-sidebar-widget",
                        children: [
                          (0, a.jsx)("div", {
                            className: "wid-title",
                            children: (0, a.jsx)("h3", {
                              children: "Categories",
                            }),
                          }),
                          (0, a.jsx)("div", {
                            className: "news-widget-categories",
                            children: (0, a.jsx)("ul", {
                              children: r.Lv.map((e, s) =>
                                (0, a.jsxs)(
                                  "li",
                                  {
                                    className: e.isActive ? "active" : "",
                                    children: [
                                      (0, a.jsx)("a", {
                                        href: e.link,
                                        children: e.text,
                                      }),
                                      " ",
                                      (0, a.jsx)("span", { children: e.count }),
                                    ],
                                  },
                                  s
                                )
                              ),
                            }),
                          }),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "single-sidebar-widget",
                        children: [
                          (0, a.jsx)("div", {
                            className: "wid-title",
                            children: (0, a.jsx)("h3", {
                              children: "Recent Post",
                            }),
                          }),
                          (0, a.jsx)("div", {
                            className: "recent-post-area",
                            children: r.CI.map((e, s) =>
                              (0, a.jsxs)(
                                "div",
                                {
                                  className: "recent-items",
                                  children: [
                                    (0, a.jsx)("div", {
                                      className: "recent-thumb",
                                      children: (0, a.jsx)(l.default, {
                                        src: e.imageSrc,
                                        width: 70,
                                        height: 70,
                                        alt: "img",
                                      }),
                                    }),
                                    (0, a.jsxs)("div", {
                                      className: "recent-content",
                                      children: [
                                        (0, a.jsx)("ul", {
                                          children: (0, a.jsxs)("li", {
                                            children: [
                                              (0, a.jsx)("i", {
                                                className:
                                                  "fa-solid fa-calendar-days",
                                              }),
                                              e.date,
                                            ],
                                          }),
                                        }),
                                        (0, a.jsx)("h6", {
                                          children: (0, a.jsx)(d.default, {
                                            href: "/news-details/".concat(e.id),
                                            dangerouslySetInnerHTML: {
                                              __html: e.title,
                                            },
                                          }),
                                        }),
                                      ],
                                    }),
                                  ],
                                },
                                s
                              )
                            ),
                          }),
                        ],
                      }),
                      (0, a.jsxs)("div", {
                        className: "single-sidebar-widget",
                        children: [
                          (0, a.jsx)("div", {
                            className: "wid-title",
                            children: (0, a.jsx)("h3", {
                              children: "Popular Tag",
                            }),
                          }),
                          (0, a.jsx)("div", {
                            className: "news-widget-categories",
                            children: (0, a.jsx)("div", {
                              className: "tagcloud",
                              children: r.Ok.map((e, s) =>
                                (0, a.jsx)(
                                  d.default,
                                  { href: e.href, children: e.text },
                                  s
                                )
                              ),
                            }),
                          }),
                        ],
                      }),
                    ],
                  }),
                }),
              ],
            }),
          }),
        });
      }
    },
    1183: function (e, s, i) {
      "use strict";
      i.d(s, {
        default: function () {
          return d;
        },
      });
      var a = i(7437);
      let l = [
        "/assets/img/brand/brand-logo.png",
        "/assets/img/brand/brand-logo-2.png",
        "/assets/img/brand/brand-logo-3.png",
        "/assets/img/brand/brand-logo-4.png",
        "/assets/img/brand/brand-logo-5.png",
        "/assets/img/brand/brand-logo.png",
        "/assets/img/brand/brand-logo-2.png",
        "/assets/img/brand/brand-logo-3.png",
        "/assets/img/brand/brand-logo-4.png",
        "/assets/img/brand/brand-logo-5.png",
      ];
      var t = i(7805),
        n = i(3267),
        r = i(6648);
      function d() {
        let e = {
          spaceBetween: 30,
          speed: 2500,
          loop: !0,
          modules: [t.pt],
          autoplay: { delay: 2500, disableOnInteraction: !1 },
          breakpoints: {
            1199: { slidesPerView: 5 },
            991: { slidesPerView: 4 },
            767: { slidesPerView: 3 },
            575: { slidesPerView: 2 },
            0: { slidesPerView: 2 },
          },
        };
        return (0, a.jsx)("div", {
          className: "container",
          children: (0, a.jsx)(n.tq, {
            ...e,
            className: "swiper brand-slider",
            children: l.map((e, s) =>
              (0, a.jsx)(
                n.o5,
                {
                  className: "swiper-slide",
                  children: (0, a.jsx)("div", {
                    className: "brand-image center",
                    children: (0, a.jsx)(r.default, {
                      width: 92,
                      height: 120,
                      style: { objectFit: "contain" },
                      src: e,
                      alt: "Brand logo ".concat(s + 1),
                    }),
                  }),
                },
                s
              )
            ),
          }),
        });
      }
    },
    6463: function (e, s, i) {
      "use strict";
      var a = i(1169);
      i.o(a, "usePathname") &&
        i.d(s, {
          usePathname: function () {
            return a.usePathname;
          },
        });
    },
  },
  function (e) {
    e.O(0, [572, 740, 640, 987, 191, 817, 971, 23, 744], function () {
      return e((e.s = 281));
    }),
      (_N_E = e.O());
  },
]);
